﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Articulo
        {public int IdArticulo { get; set; }
         public String Nombre { get; set; }
         public int Precio { get; set; }

         public Articulo() { }

        public static bool validarPrecio(string p)
            {int x;
            if (!int.TryParse(p, out x)) return false;
            if (x < 0) return false;
             return false;}

        private bool validarNombre()
            {if (Nombre is null) return false;
             return true;}

         public bool validarArticulo()
            {if (!validarNombre()) return false;
             return true;}

        public override string ToString()
        {
            return Nombre + " $" + Precio.ToString();
        }
    }
}
