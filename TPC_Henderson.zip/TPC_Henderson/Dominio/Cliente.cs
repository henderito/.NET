﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Cliente : Persona
        {public List<Venta> Compras { get; set; }
         public List<Incidencia> Incidentes { get; set; }

        public Cliente() { }

        public override bool validarFechaNac()
            {if ((FechaNac.Year + 10) > DateTime.Today.Year) return false;
             if (((FechaNac.Year + 10) == DateTime.Today.Year) && (FechaNac.Month > DateTime.Today.Month)) return false;
             if (((FechaNac.Year + 10) == DateTime.Today.Year) && (FechaNac.Month == DateTime.Today.Month) && (FechaNac.Date > DateTime.Today.Date)) return false;
             return true;}

        private bool validarCompras()
            {if (Compras is null) return false;
             foreach (Venta v in Compras)
                { if (!v.validarVenta()) return false; }
             return true;}

        private bool validarIncidentes()
            {if (Incidentes is null) return false;
             foreach (Incidencia aux in Incidentes)
                { if (!aux.validarIncidencia()) return false; }
             return true;}

        public bool validarCliente()
            {if (!validarPersona()) return false;
             if (!validarFechaNac()) return false;
             if (!validarCompras()) return false;
             if (!validarIncidentes()) return false;
             return true;}
    }
}
