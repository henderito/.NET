﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Domicilio
    {
        public String Calle { get; set; }
        public String Departamento { get; set; }
        public String Altura { get; set; }
        public String Piso { get; set; }

        public Domicilio() { }

        public override string ToString()
            {return Calle + " " + Altura + " " + Departamento + " " + Piso;}

        private bool validarCalle()
            {if (Calle is null) return false;
             return true;}

        private bool validarDepartamento()
            {if (Departamento is null) return false;
             return true;}

        private bool validarAltura()
            {if (Altura is null) return false;
             int x = 0;
             if (!int.TryParse(Altura, out x)) return false;
             if (x < 0) return false;
             return true;}

        private bool validarPiso()
            {if (Piso is null) return false;
             int x = 0;
             if (!int.TryParse(Piso, out x)) return false;
             if (x < 0) return false;
             return true;}

        public bool validarDomicilio()
            {if(!validarCalle()) return false;
             if (!validarDepartamento()) Departamento="0";
             if (!validarAltura()) return false;
             if (!validarPiso()) Piso="0";
             return true;}
    }
}
