﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Empleado : Persona
        {public DateTime FechaIngreso { get; set; }
         public int Sueldo { get; set; }
         public List<Venta> Ventas { get; set; }
         public List<Incidencia> Incidentes { get; set; }
         public int Equipo { get; set; }
         //Agregar clase Equipo y agregar el Equipo acay en Admin

         public Empleado() { }

         public override bool validarFechaNac()
            {if ((FechaNac.Year+18)>DateTime.Today.Year) return false;
             if (((FechaNac.Year + 18) == DateTime.Today.Year) && (FechaNac.Month > DateTime.Today.Month)) return false;
             if (((FechaNac.Year + 18) == DateTime.Today.Year) && (FechaNac.Month == DateTime.Today.Month) && (FechaNac.Date > DateTime.Today.Date)) return false;
             return true;}

        private bool validarFechaIngreso()
            {if ((FechaIngreso.Year) > DateTime.Today.Year) return false;
             if (((FechaIngreso.Year) == DateTime.Today.Year) && (FechaIngreso.Month > DateTime.Today.Month)) return false;
             if (((FechaIngreso.Year) == DateTime.Today.Year) && (FechaIngreso.Month == DateTime.Today.Month) && (FechaIngreso.Date > DateTime.Today.Date)) return false;
             return true;}

        private bool validarSueldo()
            {if (Sueldo < 0) return false;
             return true;}

        private bool validarVentas()
            {if (Ventas is null) return false;
             foreach (Venta aux in Ventas)
                {if(!aux.validarVenta()) return false; }
             return true;}

        private bool validarIncidentes()
            {if (Incidentes is null) return false;
             foreach (Incidencia aux in Incidentes)
                { if (!aux.validarIncidencia()) return false; }
             return true;}

         public bool validarEmpleado()
            { if (!validarFechaNac()) return false;
            if (!validarFechaIngreso()) return false;
            if (!validarSueldo()) return false;
            if (!validarVentas()) return false;
            if (!validarIncidentes()) return false;
            if (!validarPersona()) return false;
            return true;}
    }
}
