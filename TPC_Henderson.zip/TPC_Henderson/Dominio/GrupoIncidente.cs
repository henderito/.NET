﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio

{
    public class GrupoIncidente
        {public int Id { get; set; }
        public String Nombre { get; set; }        
        public String Descripcion { get; set; }

        private bool validarNombre()
        {
            if (Nombre is null) return false;
            if (Nombre.Trim() == "") return false;
            return true;
        }

        public bool validarGrupo()
        {
            if (!validarNombre()) return false;
            return true;
        }

        public override string ToString()
        {
            return Nombre;
        }
    }
}
