﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public abstract class Persona
        {public String Nombre { get; set; }
         public String Apellido { get; set; }
         public String DNI { get; set; }
         public String Telefono { get; set; }
         public String Mail { get; set; }
         public DateTime FechaNac { get; set; }
         public String Sexo { get; set; }
         public Domicilio Dom { get; set; }

         public abstract bool validarFechaNac();

        private bool validarTelefono()
            {int x = 0;
             if (!int.TryParse(Telefono, out x)) return false;
             if ((Telefono.ToString().Count() == 8) && (x >= 40000000 && x < 50000000)) return true;
             if ((Telefono.ToString().Count() == 10) && (x >= 1500000000 && x < 1600000000)) return true;
             return false;}

        private bool validarMail()
            {if (Mail.Contains("@") && ((Mail.EndsWith(".com") || (Mail.EndsWith(".com.ar"))))) return true;
             return false;}

        private bool validarDNI()
            {int x = 0;
             if (!int.TryParse(DNI, out x)) return false;
             if ((x < 999999) || (x > 99999999)) return false;
             return true;}

        private bool validarSexo()
            { if (Sexo is null) return false;
            if (!(Sexo.Equals("M") || Sexo.Equals("F"))) return false;
            return true; }

        private bool validarNombre()
            {if (Nombre is null) return false;
            if (Nombre.Trim() == "") return false;
            return true;}

        private bool validarApellido()
            {if (Apellido is null) return false;
            if (Apellido.Trim() == "") return false;
            return true;}

        public bool validarPersona()
            { if (!validarTelefono()) return false;
            if (!validarMail()) return false;
            if (!validarDNI()) return false;
            if (!validarNombre()) return false;
            if (!validarApellido()) return false;
            return true;}
    }
}
