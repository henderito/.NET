﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class SubTipoIncidente
        {public int Id { get; set; }
         public String Nombre { get; set; }
        public String Descripcion { get; set; }

        private bool validarNombre(String n)
            { if (n is null) return false;
            if (n.Trim() == "") return false;
            return true;}

        public bool validarSubTipo()
            { if (!validarNombre(Nombre)) return false;
            return true;
        }

        public override string ToString()
        {
            return Nombre;
        }

    }
}
