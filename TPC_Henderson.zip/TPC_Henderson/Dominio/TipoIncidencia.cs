﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class TipoIncidencia
        {public int IdTipo { get; set; }
        public String Nombre { get; set; }
         public String Descripcion { get; set; }

        public TipoIncidencia() { }

        private bool validarDescripcion()
            {if (Descripcion is null) return false;
            if (Descripcion.Trim() == "") return false;
            return true;}

        public bool validarTipoIncidencia()
            {if (!validarDescripcion()) return false;
             return true;}

        public override string ToString()
        {
            return Nombre;
        }
    }
}
