﻿using Dominio;
using Negocio;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class ArticuloCon
        {private DataAccess da = new DataAccess();

        public List<Articulo> listar()
            {da.setearConsulta(DBGral.ArticulosAllString());
             
             List<Articulo> lista = new List<Articulo>();
             try
                {da.leerConsulta();
                 while (da.Lector.Read())
                    {lista.Add(new Articulo() {
                         IdArticulo = da.Lector.GetInt32(0),
                         Nombre = da.Lector.GetString(1),
                         Precio = da.Lector.GetInt32(2) });}}
             catch (Exception ex)
                {throw ex;}
             finally
                { da.cerrarConexion(); }
            return lista;}

        public void insertArticulo(Articulo a)
            {string query = DBGral.ArticulosInsertString();
            string[] qParams = { a.Precio.ToString(), a.Nombre.ToString() };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
                {throw e; }
            finally
            { da.cerrarConexion(); }}

        public Articulo getArticuloById(int id)
            {string query = String.Format(DBGral.ArticulosByIdString(),id);          
            da.setearConsulta(query);
            try
            {
                da.leerConsulta();
                da.Lector.Read();
                Articulo a = new Articulo() {
                        IdArticulo = da.Lector.GetInt32(0),
                        Nombre = da.Lector.GetString(1),
                        Precio = da.Lector.GetInt32(2)
                    };
                return a;
            }
            catch (Exception ex)
                { throw ex; }
            finally
                { da.cerrarConexion(); }}

        public void updateArticulo(Articulo a)
            {string query = DBGral.ArticulosUpdateString();
            string[] qParams = { a.Nombre.ToString(), a.Precio.ToString(), a.IdArticulo.ToString() };
            da.setearConsulta(String.Format(query, qParams));
            try
                { da.executeNonQuery(); }
            catch (Exception e)
                { throw e; }
            finally
                { da.cerrarConexion(); }
        }

        public void deleteArticulo(int id)
            { string query = String.Format(DBGral.ArticulosDeleteString(),id);
            da.setearConsulta(query);
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            {da.cerrarConexion(); }
        }
    }
}
