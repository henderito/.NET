﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dominio;
using System.Data.SqlClient;
using Negocio;

namespace Negocio
{
    public class ClienteCon
        {private DataAccess da = new DataAccess();

        public List<Cliente> listar()
            {da.setearConsulta(DBGral.ClientesAllString());
            List<Cliente> lista = new List<Cliente>();
            try
                {da.leerConsulta();
                while (da.Lector.Read())
                    {lista.Add(new Cliente()
                        {Nombre = da.Lector.GetString(0),
                        Apellido = da.Lector.GetString(1),
                        FechaNac = da.Lector.GetDateTime(2),
                        DNI = da.Lector.GetString(3),
                        Telefono = da.Lector.GetString(4),
                        Mail = da.Lector.GetString(5),
                        Dom = new Domicilio()
                            {Calle = da.Lector.GetString(6),
                             Altura = da.Lector.GetString(7),
                             Piso = da.Lector.IsDBNull(8) ? "0" : da.Lector.GetString(8),
                             Departamento = da.Lector.IsDBNull(9) ? null : da.Lector.GetString(9) }
                    });}
                return lista;}
            catch (Exception ex)
                { throw ex; }
            finally
                {da.cerrarConexion();}}

        public void insertCliente(Cliente c)
            {string query = DBGral.ClientesInsertString();
            string[] qParams = { c.DNI, c.Nombre, c.Apellido, c.Sexo, c.FechaNac.ToString()};
            da.setearConsulta(String.Format(query, qParams));
            try
                { da.executeNonQuery(); }
            catch (Exception e)
                { throw e; }
            finally
                { da.cerrarConexion(); }
        }

        public Cliente getClienteById(String DNI)
        {
            string query = String.Format(DBGral.ClientesByIdString(), DNI);
            da.setearConsulta(query);
            try
            {
                da.leerConsulta();
                da.Lector.Read();
                Cliente c = new Cliente()
                {
                    Nombre = da.Lector.GetString(0),
                    Apellido = da.Lector.GetString(1),
                    FechaNac = da.Lector.GetDateTime(2),
                    DNI = da.Lector.GetString(3),
                    Telefono = da.Lector.GetString(4),
                    Mail = da.Lector.GetString(5),
                    Dom = new Domicilio()
                    {
                        Calle = da.Lector.GetString(6),
                        Altura = da.Lector.GetString(7),
                        Piso = da.Lector.IsDBNull(8) ? "0" : da.Lector.GetString(8),
                        Departamento = da.Lector.IsDBNull(9) ? null : da.Lector.GetString(9)
                    }
                };
                return c;
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
        }

        public void updateCliente(Cliente c)
        {
            string query = DBGral.ClientesUpdateString();
            string[] qParams = { c.Nombre, c.Apellido, c.Sexo, c.FechaNac.ToString(), c.DNI };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public void deleteCliente(String DNI)
        {
            string query = String.Format(DBGral.ClientesDeleteString(), DNI);
            da.setearConsulta(query);
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }
    }
}
