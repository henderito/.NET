﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dominio;

namespace Negocio
{
    public class DomicilioCon
        {private DataAccess da = new DataAccess();

        public List<Domicilio> listarDomEmpleados()
            {da.setearConsulta(DBGral.DomiciliosEmAllString());
            List<Domicilio> lista = new List<Domicilio>();
            try
                {da.leerConsulta();
                while (da.Lector.Read())
                    {lista.Add(new Domicilio()
                        {Calle = da.Lector.GetString(0),
                         Altura = da.Lector.GetString(1),
                         Piso = da.Lector.GetString(2),
                         Departamento = da.Lector.GetString(3)
                    });}
            }
            catch (Exception ex)
                { throw ex; }
            finally
                { da.cerrarConexion(); }
            return lista;
        }

        public void insertDomicilioEmpleado(String DNIe, Domicilio d)
        {
            string query = DBGral.DomiciliosEmInsertString();
            string[] qParams = { DNIe, d.Calle, d.Altura, d.Piso, d.Departamento };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public Domicilio getDomicilioEmpleadoById(String DNI)
        {
            string query = String.Format(DBGral.DomiciliosEmByIdString(), DNI);
            da.setearConsulta(query);
            try
            {
                da.leerConsulta();
                da.Lector.Read();
                Domicilio a = new Domicilio()
                {
                    Calle = da.Lector.GetString(0),
                    Altura = da.Lector.GetString(1),
                    Piso = da.Lector.GetString(2),
                    Departamento = da.Lector.GetString(3)
                };
                return a;
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
        }

        public void updateDomicilioEmpleado(Domicilio d, String DNIe)
        {
            string query = DBGral.DomiciliosEmUpdateString();
            string[] qParams = {  d.Calle, d.Altura, d.Piso, d.Departamento, DNIe };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public void deleteDomicilioEmpleado(String DNIe)
        {
            string query = String.Format(DBGral.DomiciliosEmDeleteString(), DNIe);
            da.setearConsulta(query);
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public List<Domicilio> listarDomClientes()
        {
            da.setearConsulta(DBGral.DomiciliosClAllString());
            List<Domicilio> lista = new List<Domicilio>();
            try
            {
                da.leerConsulta();
                while (da.Lector.Read())
                {
                    lista.Add(new Domicilio()
                    {
                        Calle = da.Lector.GetString(0),
                        Altura = da.Lector.GetString(1),
                        Piso = da.Lector.GetString(2),
                        Departamento = da.Lector.GetString(3)
                    });
                }
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
            return lista;
        }

        public void insertDomicilioCliente(String DNIc, Domicilio d)
        {
            string query = DBGral.DomiciliosClInsertString();
            string[] qParams = { DNIc, d.Calle, d.Altura, d.Piso, d.Departamento };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public Domicilio getDomicilioClienteById(String DNI)
        {
            string query = String.Format(DBGral.DomiciliosClByIdString(), DNI);
            da.setearConsulta(query);
            try
            {
                da.leerConsulta();
                da.Lector.Read();
                Domicilio a = new Domicilio()
                {
                    Calle = da.Lector.GetString(0),
                    Altura = da.Lector.GetString(1),
                    Piso = da.Lector.GetString(2),
                    Departamento = da.Lector.GetString(3)
                };
                return a;
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
        }

        public void updateDomicilioCliente(Domicilio d, String DNIc)
        {
            string query = DBGral.DomiciliosClUpdateString();
            string[] qParams = { d.Calle, d.Altura, d.Piso, d.Departamento, DNIc };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public void deleteDomicilioCliente(String DNIc)
        {
            string query = String.Format(DBGral.DomiciliosClDeleteString(), DNIc);
            da.setearConsulta(query);
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }
    }
}
