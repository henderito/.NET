﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dominio;

namespace Negocio
{
    public class EmpleadoCon
        {private DataAccess da = new DataAccess();

        public List<Empleado> listar()
            {da.setearConsulta(DBGral.EmpleadosAllString());

            List<Empleado> lista = new List<Empleado>();
            try
                {da.leerConsulta();
                while (da.Lector.Read())
                    {lista.Add(new Empleado()
                        {DNI = da.Lector.GetString(0),
                        Nombre = da.Lector.GetString(1),
                        Apellido = da.Lector.GetString(2),
                        FechaNac = da.Lector.GetDateTime(3),
                        FechaIngreso = da.Lector.GetDateTime(4),
                        Sexo = da.Lector.GetString(5),
                        Sueldo = da.Lector.GetInt32(6)                       
                    });
                }
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
            return lista;
        }

        public void insertEmpleado(Empleado e)
        {
            string query = DBGral.EmpleadosInsertString();           
            string[] qParams = { e.DNI, e.Nombre, e.Apellido, e.FechaNac.ToString(), e.FechaIngreso.ToString(), e.Sexo, e.Sueldo.ToString(), e.Equipo.ToString()};
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
        }

        public Empleado getEmpleadoById(String DNI)
        {
            string query = String.Format(DBGral.EmpleadosByIdString(), DNI);
            da.setearConsulta(query);
            try
            {
                da.leerConsulta();
                da.Lector.Read();
                Empleado e = new Empleado()
                    {DNI = da.Lector.GetString(0),
                    Nombre = da.Lector.GetString(1),
                    Apellido = da.Lector.GetString(2),
                    FechaNac = da.Lector.GetDateTime(3),
                    FechaIngreso = da.Lector.GetDateTime(4),
                    Sexo = da.Lector.GetString(5),
                    Sueldo = da.Lector.GetInt32(6)
                };
                return e;
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
        }

        public void updateEmpleado(Empleado e)
        {
            string query = DBGral.EmpleadosUpdateString();
            string[] qParams = { e.Nombre, e.Apellido, e.FechaNac.ToString(), e.FechaIngreso.ToString(), e.Sexo, e.Sueldo.ToString(), e.Equipo.ToString(), e.DNI };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
        }

        public void deleteEmpleado(String DNI)
        {
            string query = String.Format(DBGral.EmpleadosDeleteString(), DNI);
            da.setearConsulta(query);
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }
    }
}
