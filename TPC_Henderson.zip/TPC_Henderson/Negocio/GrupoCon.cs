﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dominio;

namespace Negocio
{
    public class GrupoCon
    {
        private DataAccess da = new DataAccess();

        public List<GrupoIncidente> listar()
        {
            da.setearConsulta(DBGral.GrupoIncidenteAllString());

            List<GrupoIncidente> lista = new List<GrupoIncidente>();
            try
            {
                da.leerConsulta();
                while (da.Lector.Read())
                {
                    lista.Add(new GrupoIncidente()
                    {
                        Id = da.Lector.GetInt32(0),
                        Nombre = da.Lector.GetString(3),
                        Descripcion = da.Lector.GetString(1)
                    });
                }
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
            return lista;
        }

        public void insertGrupoIncidente(GrupoIncidente g, int idT)
        {
            string query = DBGral.GrupoIncidenteInsertString();
            string[] qParams = { g.Descripcion, g.Nombre, idT.ToString() };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public GrupoIncidente getGrupoIncidenteById(int id)
        {
            string query = String.Format(DBGral.GrupoIncidenteByIdString(), id);
            da.setearConsulta(query);
            try
            {
                da.leerConsulta();
                da.Lector.Read();
                GrupoIncidente g = new GrupoIncidente()
                {
                    Id = da.Lector.GetInt32(0),
                    Nombre = da.Lector.GetString(3),
                    Descripcion = da.Lector.GetString(1)
                };
                return g;
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
        }

        public GrupoIncidente getGrupoIncidenteByIdTipo(int id)
        {
            string query = String.Format(DBGral.GrupoIncidenteByIdTipoString(), id);
            da.setearConsulta(query);
            try
            {
                da.leerConsulta();
                da.Lector.Read();
                GrupoIncidente g = new GrupoIncidente()
                {
                    Id = da.Lector.GetInt32(0),
                    Nombre = da.Lector.GetString(3),
                    Descripcion = da.Lector.GetString(1)
                };
                return g;
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
        }

        public void updateGrupoIncidente(GrupoIncidente g, int idT)
        {
            string query = DBGral.GrupoIncidenteUpdateString();
            string[] qParams = {  g.Descripcion, g.Nombre.ToString(), idT.ToString(), g.Id.ToString() };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public void deleteGrupoIncidente(int id)
        {
            string query = String.Format(DBGral.GrupoIncidenteDeleteString(), id);
            da.setearConsulta(query);
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }
    }
}
