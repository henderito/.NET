﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dominio;

namespace Negocio
{
    public class IncidenciaCon
    {
        private DataAccess da = new DataAccess();

        public List<Incidencia> listar()
        {
            da.setearConsulta(DBGral.IncidentesAllString());

            List<Incidencia> lista = new List<Incidencia>();
            try
            {
                da.leerConsulta();
                while (da.Lector.Read())
                {
                    lista.Add(new Incidencia()
                    {
                        IdIncidencia = da.Lector.GetInt32(0),
                        Estado = da.Lector.GetString(1),
                        Cli = new ClienteCon().getClienteById(da.Lector.GetString(2)),
                        Ven = new EmpleadoCon().getEmpleadoById(da.Lector.GetString(3)),
                        PrioridadAlta = da.Lector.GetBoolean(4),
                        Tipo = new TipoIncidenciaCon().getTipoIncidenciaById(da.Lector.GetInt32(5)),
                        ventaRelacionada = new VentaCon().getVentaById(da.Lector.GetInt32(6))
                    });
                }
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
            return lista;
        }

        public void insertIncidencia(Incidencia i)
        {
            string query = DBGral.IncidentesInsertString();            
            string[] qParams = { i.Estado, i.Cli.DNI.ToString(), i.Ven.DNI.ToString(), i.PrioridadAlta.ToString(),
                                 i.Tipo.IdTipo.ToString(), i.ventaRelacionada.IdVenta.ToString() };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
        }

        public Incidencia getIncidenciaById(int id)
        {
            string query = String.Format(DBGral.IncidentesByIdString(), id);
            da.setearConsulta(query);
            try
            {
                da.leerConsulta();
                da.Lector.Read();
                Incidencia i = new Incidencia()
                {
                    IdIncidencia = da.Lector.GetInt32(0),
                    Estado = da.Lector.GetString(1),
                    Cli = new ClienteCon().getClienteById(da.Lector.GetString(2)),
                    Ven = new EmpleadoCon().getEmpleadoById(da.Lector.GetString(3)),
                    PrioridadAlta = da.Lector.GetBoolean(4),
                    Tipo = new TipoIncidenciaCon().getTipoIncidenciaById(da.Lector.GetInt32(5)),
                    ventaRelacionada = new VentaCon().getVentaById(da.Lector.GetInt32(6))
                };
                return i;
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
        }

        public void updateIncidencia(Incidencia i)
        {
            string query = DBGral.IncidentesUpdateString();
            string[] qParams = { i.Estado, i.Cli.DNI.ToString(), i.Ven.DNI.ToString(), i.PrioridadAlta.ToString(),
                                 i.Tipo.IdTipo.ToString(), i.ventaRelacionada.IdVenta.ToString(), i.IdIncidencia.ToString() };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public void deleteIncidencia(int id)
        {
            string query = String.Format(DBGral.IncidentesDeleteString(), id);
            da.setearConsulta(query);
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }
    }
}
