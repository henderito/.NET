﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dominio;

namespace Negocio
{
    public class InteresCon
        {private DataAccess da = new DataAccess();

        public List<Interes> listar()
        {
            da.setearConsulta(DBGral.InteresesAllString());

            List<Interes> lista = new List<Interes>();
            try
            {
                da.leerConsulta();
                while (da.Lector.Read())
                {
                    lista.Add(new Interes()
                    {
                        Id = da.Lector.GetInt32(0),                        
                        Porcentaje = da.Lector.GetInt32(1),
                        Nombre = da.Lector.GetString(2)
                    });
                }
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
            return lista;
        }

        public void insertInteres(Interes i)
        {
            string query = DBGral.InteresesInsertString();
            string[] qParams = { i.Nombre, i.Porcentaje.ToString() };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public Interes getInteresById(int id)
        {
            string query = String.Format(DBGral.InteresesByIdString(), id);
            da.setearConsulta(query);
            try
            {
                da.leerConsulta();
                da.Lector.Read();
                Interes i = new Interes()
                {
                    Id = da.Lector.GetInt32(0),
                    Porcentaje = da.Lector.GetInt32(1),
                    Nombre = da.Lector.GetString(2)
                };
                return i;
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
        }

        public void updateInteres(Interes i)
        {
            string query = DBGral.InteresesUpdateString();
            string[] qParams = { i.Nombre, i.Porcentaje.ToString(), i.Id.ToString() };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public void deleteInteres(int id)
        {
            string query = String.Format(DBGral.InteresesDeleteString(), id);
            da.setearConsulta(query);
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }
    }
}
