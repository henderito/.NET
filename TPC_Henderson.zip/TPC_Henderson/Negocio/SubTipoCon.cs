﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dominio;

namespace Negocio
{
    public class SubTipoCon
        {private DataAccess da = new DataAccess();

        public List<SubTipoIncidente> listar()
            {da.setearConsulta(DBGral.ArticulosAllString());

            List<SubTipoIncidente> lista = new List<SubTipoIncidente>();
            try
            {
                da.leerConsulta();
                while (da.Lector.Read())
                {
                    lista.Add(new SubTipoIncidente()
                    {
                        Id = da.Lector.GetInt32(0),
                        Nombre = da.Lector.GetString(3),
                        Descripcion = da.Lector.GetString(1)                        
                    });
                }
                return lista;
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }            
        }

        public void insertSubTipoIncidente(SubTipoIncidente st, int idG)
        {
            string query = DBGral.SubTipoIncidenteInsertString();
            string[] qParams = { st.Descripcion, st.Nombre, idG.ToString() };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public SubTipoIncidente getSubTipoIncidenteById(int id)
            {string query = String.Format(DBGral.SubTipoIncidenteByIdString(), id);
            da.setearConsulta(query);
                try
                    {da.leerConsulta();
                     da.Lector.Read();
                        SubTipoIncidente st = new SubTipoIncidente()
                        {
                            Id = da.Lector.GetInt32(0),
                            Nombre = da.Lector.GetString(3),
                            Descripcion = da.Lector.GetString(1)
                        };
                     return st;}
            catch (Exception ex)
                { throw ex; }
            finally
                { da.cerrarConexion(); }}

        public List<SubTipoIncidente> getSubTipoIncidenteByIdGrupo(int id)
            {string query = String.Format(DBGral.SubTipoIncidenteByIdGrupoString(), id);
            da.setearConsulta(query);
            List<SubTipoIncidente> lista = new List<SubTipoIncidente>();
            try
                {da.leerConsulta();
                while (da.Lector.Read())
                {
                    SubTipoIncidente st = new SubTipoIncidente()
                    {
                        Id = da.Lector.GetInt32(0),
                        Nombre = da.Lector.GetString(3),
                        Descripcion = da.Lector.GetString(1)
                    };
                    lista.Add(st);
                }
                return lista;}
                catch (Exception ex)
                { throw ex; }
                finally
                { da.cerrarConexion(); } }

        public void updateSubTipoIncidente(SubTipoIncidente st, int idG)
            {string query = DBGral.SubTipoIncidenteUpdateString();
            string[] qParams = { st.Descripcion, idG.ToString(), st.Nombre, st.Id.ToString() };
         da.setearConsulta(String.Format(query, qParams));
        try
        { da.executeNonQuery(); }
        catch (Exception e)
        { throw e; }
        finally
        { da.cerrarConexion(); }
    }

    public void deleteSubTipoIncidente(int id)
    {
        string query = String.Format(DBGral.SubTipoIncidenteDeleteString(), id);
        da.setearConsulta(query);
        try
        { da.executeNonQuery(); }
        catch (Exception e)
        { throw e; }
        finally
        { da.cerrarConexion(); }
    }
}
}
