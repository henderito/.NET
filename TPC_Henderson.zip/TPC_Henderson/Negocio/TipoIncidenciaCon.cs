﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dominio;

namespace Negocio
{
    public class TipoIncidenciaCon
        {private DataAccess da = new DataAccess();

        public List<TipoIncidencia> listar()
        {
            da.setearConsulta(DBGral.TipoIncidenteAllString());

            List<TipoIncidencia> lista = new List<TipoIncidencia>();
            try
            {
                da.leerConsulta();
                while (da.Lector.Read())
                {
                    lista.Add(new TipoIncidencia()
                    {
                        IdTipo = da.Lector.GetInt32(0),
                        Nombre = da.Lector.GetString(2),
                        Descripcion = da.Lector.GetString(1)
                    });
                }
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
            return lista;
        }

        public void insertTipoIncidencia(TipoIncidencia ti)
        {
            string query = DBGral.TipoIncidenteInsertString();           
            string[] qParams = { ti.Descripcion, ti.Nombre };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public TipoIncidencia getTipoIncidenciaById(int id)
        {
            string query = String.Format(DBGral.TipoIncidenteByIdString(), id);
            da.setearConsulta(query);
            try
            {
                da.leerConsulta();
                da.Lector.Read();
                TipoIncidencia ti = new TipoIncidencia()
                {
                    IdTipo = da.Lector.GetInt32(0),
                    Nombre = da.Lector.GetString(2),
                    Descripcion = da.Lector.GetString(1)
                };
                return ti;
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
        }

        public void updateTipoIncidencia(TipoIncidencia ti)
        {
            string query = DBGral.TipoIncidenteUpdateString();
            string[] qParams = { ti.Descripcion, ti.Nombre, ti.IdTipo.ToString() };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public void deleteArticulo(int id)
        {
            string query = String.Format(DBGral.TipoIncidenteDeleteString(), id);
            da.setearConsulta(query);
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }
    }
}
