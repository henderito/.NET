﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dominio;

namespace Negocio
{
    public class VentaCon
    {
        private DataAccess da = new DataAccess();

        public List<Venta> listar()
        {
            da.setearConsulta(DBGral.VentasAllString());

            List<Venta> lista = new List<Venta>();
            try
            {
                da.leerConsulta();
                while (da.Lector.Read())
                {
                    lista.Add(new Venta()
                    {
                        IdVenta = da.Lector.GetInt32(0),
                        Ven = new EmpleadoCon().getEmpleadoById(da.Lector.GetString(1)),
                        Cli = new ClienteCon().getClienteById(da.Lector.GetString(2)),
                        Int = new InteresCon().getInteresById(da.Lector.GetInt32(3)),
                        Fecha = da.Lector.GetDateTime(4)
                    });
                }
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
            return lista;
        }

        public void insertVenta(Venta v)
        {
            string query = DBGral.VentasInsertString();
            string[] qParams = { v.Ven.DNI, v.Cli.DNI, v.Int.Id.ToString(), v.Fecha.ToString() };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public Venta getVentaById(int id)
        {
            string query = String.Format(DBGral.VentasByIdString(), id);
            da.setearConsulta(query);
            try
            {
                da.leerConsulta();
                da.Lector.Read();
                Venta v = new Venta()
                {
                    IdVenta = da.Lector.GetInt32(0),
                    Ven = new EmpleadoCon().getEmpleadoById(da.Lector.GetString(1)),
                    Cli = new ClienteCon().getClienteById(da.Lector.GetString(2)),
                    Int = new InteresCon().getInteresById(da.Lector.GetInt32(3)),
                    Fecha = da.Lector.GetDateTime(4)
                };
                return v;
            }
            catch (Exception ex)
            { throw ex; }
            finally
            { da.cerrarConexion(); }
        }

        public void updateVenta(Venta v)
        {
            string query = DBGral.ArticulosUpdateString();
            string[] qParams = { v.Ven.DNI, v.Cli.DNI, v.Int.Id.ToString(), v.Fecha.ToString(), v.IdVenta.ToString() };
            da.setearConsulta(String.Format(query, qParams));
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }

        public void deleteVenta(int id)
        {
            string query = String.Format(DBGral.VentasDeleteString(), id);
            da.setearConsulta(query);
            try
            { da.executeNonQuery(); }
            catch (Exception e)
            { throw e; }
            finally
            { da.cerrarConexion(); }
        }
    }
}
