﻿namespace Forms
{
    partial class FormControlGeneral
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNuevaVenta = new System.Windows.Forms.Button();
            this.btnNuevaIncidencia = new System.Windows.Forms.Button();
            this.btnNuevoCliente = new System.Windows.Forms.Button();
            this.btnDatosMaestros = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnNuevaVenta
            // 
            this.btnNuevaVenta.Location = new System.Drawing.Point(248, 57);
            this.btnNuevaVenta.Name = "btnNuevaVenta";
            this.btnNuevaVenta.Size = new System.Drawing.Size(164, 23);
            this.btnNuevaVenta.TabIndex = 0;
            this.btnNuevaVenta.Text = "NUEVA VENTA";
            this.btnNuevaVenta.UseVisualStyleBackColor = true;
            this.btnNuevaVenta.Click += new System.EventHandler(this.nuevaVenta);
            // 
            // btnNuevaIncidencia
            // 
            this.btnNuevaIncidencia.Location = new System.Drawing.Point(29, 57);
            this.btnNuevaIncidencia.Name = "btnNuevaIncidencia";
            this.btnNuevaIncidencia.Size = new System.Drawing.Size(193, 23);
            this.btnNuevaIncidencia.TabIndex = 1;
            this.btnNuevaIncidencia.Text = "NUEVA INCIDENCIA";
            this.btnNuevaIncidencia.UseVisualStyleBackColor = true;
            this.btnNuevaIncidencia.Click += new System.EventHandler(this.nuevoIncidente);
            // 
            // btnNuevoCliente
            // 
            this.btnNuevoCliente.Location = new System.Drawing.Point(248, 97);
            this.btnNuevoCliente.Name = "btnNuevoCliente";
            this.btnNuevoCliente.Size = new System.Drawing.Size(164, 45);
            this.btnNuevoCliente.TabIndex = 2;
            this.btnNuevoCliente.Text = "NUEVO USUARIO";
            this.btnNuevoCliente.UseVisualStyleBackColor = true;
            this.btnNuevoCliente.Click += new System.EventHandler(this.nuevoUsuario);
            // 
            // btnDatosMaestros
            // 
            this.btnDatosMaestros.Location = new System.Drawing.Point(29, 97);
            this.btnDatosMaestros.Name = "btnDatosMaestros";
            this.btnDatosMaestros.Size = new System.Drawing.Size(193, 45);
            this.btnDatosMaestros.TabIndex = 3;
            this.btnDatosMaestros.Text = "GENERACION DE DATOS MAESTROS";
            this.btnDatosMaestros.UseVisualStyleBackColor = true;
            this.btnDatosMaestros.Click += new System.EventHandler(this.generarDatosMaestros);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(176, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Bienvenido!!";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(96, 172);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(252, 45);
            this.button1.TabIndex = 5;
            this.button1.Text = "MANIPULACION DE DATOS MAESTROS";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // FormControlGeneral
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(431, 245);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnDatosMaestros);
            this.Controls.Add(this.btnNuevoCliente);
            this.Controls.Add(this.btnNuevaIncidencia);
            this.Controls.Add(this.btnNuevaVenta);
            this.Name = "FormControlGeneral";
            this.Text = "Panel General";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNuevaVenta;
        private System.Windows.Forms.Button btnNuevaIncidencia;
        private System.Windows.Forms.Button btnNuevoCliente;
        private System.Windows.Forms.Button btnDatosMaestros;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}

