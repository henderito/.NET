﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Negocio;
using System.Windows.Forms;

namespace Forms
{
    public partial class FormControlGeneral : Form
    {
        public FormControlGeneral()
        {
           // if (new Login().validarAcceso())
                InitializeComponent();

        }
        private void nuevoUsuario(object sender, EventArgs e)
            { NuevoUsuario aU = new NuevoUsuario();
              aU.Show(); }

        private void nuevoIncidente(object sender, EventArgs e)
            { NuevoIncidente nI = new NuevoIncidente();
              nI.Show(); }

        private void nuevaVenta(object sender, EventArgs e)
            { NuevaVenta nV = new NuevaVenta();
              nV.Show(); }

        private void generarDatosMaestros(object sender, EventArgs e)
            { GenerarDatosMaestros gDM = new GenerarDatosMaestros();
              gDM.Show(); }

        private void modificarDatosMaestros(object sender, EventArgs e)
            { ManipularDatosMaestros mDm = new ManipularDatosMaestros();
            mDm.Show();
        }
    }
}
