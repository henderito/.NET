﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dominio;
using Negocio;

namespace Forms
{
    public partial class GenerarDatosMaestros : Form
    {
        private List<TipoIncidencia> lTipos = new List<TipoIncidencia>();
        private List<GrupoIncidente> lGrupos = new List<GrupoIncidente>();

        public GenerarDatosMaestros()
        {
            InitializeComponent();
            refreshTipos();
        }

        private void refreshTipos()
            {lTipos = new TipoIncidenciaCon().listar();
            cmbTipoSubtipo.DataSource = lTipos;
            cmbTipoGrupo.DataSource = lTipos;}

        public void agregarTipo(object sender, EventArgs ea)
            {string nombre = txtTipoIncidenciaNombre.Text.ToString();
             string descripcion = txtDescTipo.Text.ToString();
            TipoIncidencia ti = new TipoIncidencia() {Nombre=nombre, Descripcion=descripcion };
            if (!ti.validarTipoIncidencia())
                { MessageBox.Show("Datos Incorrectos");
                return;}
            try { new TipoIncidenciaCon().insertTipoIncidencia(ti); }
            catch (Exception ex)
            {
                MessageBox.Show("Hubo un error con la base de datos, intente nuevamente -- Es posible que haya completado mal los campos");
                return;
            }
            finally
            {
                lTipos.Add(ti);
                refreshTipos();
                txtTipoIncidenciaNombre.Text = "";
                txtDescTipo.Text = "";
            }
        }

        public void agregarGrupo(object sender, EventArgs ea)
            {if (cmbTipoGrupo.SelectedItem is null)
            {
                MessageBox.Show("Ingrese un Tipo valido!");
                return;
            }
            string nombre = txtGrupo.Text.ToString();
            string descripcion = txtDescGrupo.Text.ToString();
            GrupoIncidente gI = new GrupoIncidente() { Nombre = nombre, Descripcion = descripcion };
            if(!gI.validarGrupo())
                {MessageBox.Show("Datos Incorrectos");
                return;}
            try { new GrupoCon().insertGrupoIncidente(gI, ((TipoIncidencia)cmbTipoGrupo.SelectedItem).IdTipo); }
            catch (Exception ex)
            {
                MessageBox.Show("Hubo un error con la base de datos, intente nuevamente -- Es posible que haya completado mal los campos");
                return;
            }
            finally
            {
                txtGrupo.Text = "";
                txtDescGrupo.Text = "";
            }
        }

        public void agregarSubTipo(object sender, EventArgs ea)
            {if(cmbGrupoSubtipo.SelectedItem is null)
            {
                MessageBox.Show("Ingrese un Grupo valido!");
                return;
            }
            int idGrupo = ((GrupoIncidente)cmbGrupoSubtipo.SelectedItem).Id;
            string nombre = txtSubTipo.Text.ToString();
            string descripcion = txtDescSubtipo.Text.ToString();
            SubTipoIncidente sT = new SubTipoIncidente() { Nombre = nombre, Descripcion = descripcion };
            if (!sT.validarSubTipo())
                {MessageBox.Show("Datos Incorrectos");
                return;}
            try { new SubTipoCon().insertSubTipoIncidente(sT, idGrupo); }
            catch (Exception ex)
            {
                MessageBox.Show("Hubo un error con la base de datos, intente nuevamente -- Es posible que haya completado mal los campos");
                return;
            }
            finally
            {
                txtSubTipo.Text = "";
                txtDescSubtipo.Text = "";
            }
        }

        public void agregarArticulo(object sender, EventArgs ea)
        { string nombre = txtNombreArt.Text.ToString();
            string precio = txtPrecioArt.Text.ToString();
            if(!Articulo.validarPrecio(precio))
                {MessageBox.Show("Datos Incorrectos");
                return;}
            int p;
            int.TryParse(precio, out p);
            try { new ArticuloCon().insertArticulo(new Articulo() { Nombre = nombre, Precio = p }); }
            catch (Exception ex)
            {
                MessageBox.Show("Hubo un error con la base de datos, intente nuevamente -- Es posible que haya completado mal los campos");
                return;
            }
            finally
            {
                txtNombreArt.Text = "";
                txtPrecioArt.Text = "";
            }
        }

        private void tipoIncidChange(object sender, EventArgs e)
            {try
                { cmbGrupoSubtipo.DataSource = new GrupoCon().getGrupoIncidenteByIdTipo(((TipoIncidencia)cmbTipoSubtipo.SelectedItem).IdTipo); }
            catch (Exception ex) { } }
    }
}
